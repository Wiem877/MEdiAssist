<?php
// Commencer par démarrer la session
session_start();

// Vérifier que les données sont envoyées via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Assigner les données envoyées via POST à des variables
    $idUser = $_SESSION['cin'] ?? null;
    $idMedecin = $_POST['idMedecin'] ?? null;
    $oldDate = $_POST['oldDate'] ?? null;
    $oldHeure = $_POST['oldHeure'] ?? null;
    $newDate = $_POST['newDate'] ?? null;
    $newHeure = $_POST['newHeure'] ?? null;

    // Vérifier si toutes les données nécessaires sont présentes
    if (!$idUser || !$idMedecin || !$oldDate || !$oldHeure || !$newDate || !$newHeure) {
        echo json_encode(["success" => false, "message" => "Données manquantes ou invalides"]);
        exit;
    }

    // Connexion avec la base de données
    $mysqli = new mysqli("localhost", "root", "", "gestionPatient");

    // Vérification de la connexion
    if ($mysqli->connect_error) {
        echo json_encode(["success" => false, "message" => "Erreur de connexion : " . $mysqli->connect_error]);
        exit;
    }

    // Préparer la requête SQL pour mettre à jour le rendez-vous
    $stmt = $mysqli->prepare("UPDATE RendezVous SET dateR = ?, heureR = ? WHERE idUser = ? AND idMedecin = ? AND dateR = ? AND heureR = ?");
    if (!$stmt) {
        echo json_encode(["success" => false, "message" => "Erreur de préparation : " . $mysqli->error]);
        exit;
    }

    // Assigner les paramètres à la requête préparée
    $stmt->bind_param("ssisss", $newDate, $newHeure, $idUser, $idMedecin, $oldDate, $oldHeure);

    // Exécuter la requête
    if ($stmt->execute()) {
        // Vérifier si des lignes ont été affectées (mise à jour réussie)
        if ($stmt->affected_rows > 0) {
            echo json_encode(["success" => true, "message" => "Rendez-vous modifié avec succès"]);
        } else {
            echo json_encode(["success" => false, "message" => "Aucune modification effectuée"]);
        }
    } else {
        // Si erreur d'exécution
        echo json_encode(["success" => false, "message" => "Erreur d'exécution : " . $stmt->error]);
    }

    // Fermer les objets préparés et la connexion
    $stmt->close();
    $mysqli->close();
}
?>





