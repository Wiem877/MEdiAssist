<?php
session_start();
require_once 'connexion.php';

if (!isset($_SESSION['cin'])) {
    exit("Non autorisé");
}
$rendezVousList = [];
$idUser = $_SESSION['cin'];

// Récupération des médecins
$medecins_result = $conn->query("SELECT * FROM Medecin ORDER BY nomMedecin");
$medecins = [];
while ($row = $medecins_result->fetch_assoc()) {
    $medecins[] = $row;
}

// Ajout de rendez-vous
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_appointment'])) {
    $idMedecin = $_POST['idMedecin'];
    $dateR = $_POST['dateR'];
    $heureR = $_POST['heureR'];
    $typeCons = $_POST['typeCons'];

    if (empty($idMedecin) || empty($dateR) || empty($heureR) || empty($typeCons)) {
        $error = "Veuillez remplir tous les champs obligatoires";
    } else {
        try {
            $stmt = $conn->prepare("INSERT INTO RendezVous (idMedecin, idUser, dateR, heureR, typeCons) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("iisss", $idMedecin, $idUser, $dateR, $heureR, $typeCons);
            if ($stmt->execute()) {
                $success = "Rendez-vous ajouté avec succès!";
            } else {
                $error = "Une erreur est survenue lors de l'ajout.";
            }
        } catch (Exception $e) {
            if ($conn->errno == 1062) {
                $error = "Vous avez déjà un rendez-vous avec ce médecin à cette date et heure.";
            } else {
                $error = "Erreur technique: " . $e->getMessage();
            }
        }
    }
}

// Récupération des rendez-vous
$stmt = $conn->prepare("
    SELECT R.*, M.nomMedecin, M.specialite 
    FROM RendezVous R
    JOIN Medecin M ON R.idMedecin = M.idMedecin
    WHERE R.idUser = ? 
    ORDER BY R.dateR DESC, R.heureR DESC
");
$stmt->bind_param("i", $idUser);
$stmt->execute();
$result = $stmt->get_result();
$appointments = [];
while ($row = $result->fetch_assoc()) {
    $appointments[] = $row;
}

// Rendez-vous à venir (7 jours)
$today = date('Y-m-d');
$nextWeek = date('Y-m-d', strtotime('+7 days'));
$stmt = $conn->prepare("
    SELECT R.*, M.nomMedecin 
    FROM RendezVous R
    JOIN Medecin M ON R.idMedecin = M.idMedecin
    WHERE R.idUser = ? AND R.dateR BETWEEN ? AND ? 
    ORDER BY R.dateR ASC, R.heureR ASC
");
$stmt->bind_param("iss", $idUser, $today, $nextWeek);
$stmt->execute();
$result = $stmt->get_result();
$upcoming = [];
while ($row = $result->fetch_assoc()) {
    $upcoming[] = $row;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>MedAssist - Mes Rendez-vous</title>
    <link href="appointment.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<div class="container">
    <div class="row">
        <!-- Rendez-vous existants -->
        <div class="col-md-8">
            <h1 class="mb-4"><i class="bi bi-calendar-check"></i> Mes Rendez-vous Médicaux</h1>

            <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <?php if (isset($success)): ?>
                <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
            <?php endif; ?>

            <?php if (empty($appointments)): ?>
                <div class="alert alert-info">Vous n'avez aucun rendez-vous enregistré.</div>
            <?php else: ?>
                <div class="list-group">
                    <?php foreach ($appointments as $rdv): ?>
                        <div class="list-group-item appointment-card mb-3">
                            <div class="d-flex w-100 justify-content-between">
                                <h5 class="mb-1">
                                    <span class="badge bg-primary"><?= htmlspecialchars($rdv['typeCons']) ?></span>
                                    Dr. <?= htmlspecialchars($rdv['nomMedecin']) ?> (<?= htmlspecialchars($rdv['specialite']) ?>)
                                </h5>
                                <small><?= date('d/m/Y', strtotime($rdv['dateR'])) ?></small>
                            </div>
                            <p class="mb-1"><i class="bi bi-clock"></i> <?= htmlspecialchars($rdv['heureR']) ?></p>
                            <div class="d-flex justify-content-end">
                                <button type="button" class="btn btn-sm btn-outline-danger me-2" data-idmedecin="<?= $rdv['idMedecin'] ?>" data-date="<?= $rdv['dateR'] ?>" data-heure="<?= $rdv['heureR'] ?>">
                                    <i class="bi bi-trash"></i> Annuler
                                </button>

                                <form action="modifierRendezVous.php" method="post" style="display:inline;">
                                    <input type="hidden" name="idMedecin" value="<?= $rdv['idMedecin'] ?>">
                                    <input type="hidden" name="dateR" value="<?= $rdv['dateR'] ?>">
                                    <input type="hidden" name="heureR" value="<?= $rdv['heureR'] ?>">
                                    <button type="submit" class="btn btn-sm btn-outline-primary">
                                        <i class="bi bi-pencil"></i> Modifier
                                    </button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Formulaire d'ajout -->
        <div class="col-md-4">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0"><i class="bi bi-plus-circle"></i> Nouveau Rendez-vous</h5>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <div class="mb-3">
                            <label for="idMedecin" class="form-label">Médecin</label>
                            <select class="form-select" id="idMedecin" name="idMedecin" required>
                                <option value="">Choisir un médecin...</option>
                                <?php foreach ($medecins as $med): ?>
                                    <option value="<?= htmlspecialchars($med['idMedecin']) ?>">
                                        Dr. <?= htmlspecialchars($med['nomMedecin']) ?> (<?= htmlspecialchars($med['specialite']) ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="dateR" class="form-label">Date</label>
                            <input type="date" class="form-control" id="dateR" name="dateR" required>
                        </div>
                        <div class="mb-3">
                            <label for="heureR" class="form-label">Heure</label>
                            <input type="time" class="form-control" id="heureR" name="heureR" required>
                        </div>
                        <div class="mb-3">
                            <label for="typeCons" class="form-label">Type de consultation</label>
                            <select class="form-select" id="typeCons" name="typeCons" required>
                                <option value="">Choisir un type...</option>
                                <option value="Consultation générale">Consultation générale</option>
                                <option value="Suivi de traitement">Suivi de traitement</option>
                                <option value="Analyse médicale">Analyse médicale</option>
                                <option value="Vaccination">Vaccination</option>
                                <option value="Urgence">Urgence</option>
                            </select>
                        </div>
                        <button type="submit" name="add_appointment" class="btn btn-primary w-100">
                            <i class="bi bi-save"></i> Prendre Rendez-vous
                        </button>
                    </form>
                </div>
            </div>

            <!-- Rendez-vous à venir -->
            <div class="card mt-4">
                <div class="card-header bg-info text-white">
                    <h5 class="mb-0"><i class="bi bi-calendar-event"></i> Rendez-vous à venir</h5>
                </div>
                <div class="card-body">
                    <?php if (empty($upcoming)): ?>
                        <p class="text-muted">Aucun rendez-vous dans les 7 prochains jours.</p>
                    <?php else: ?>
                        <ul class="list-group list-group-flush">
                            <?php foreach ($upcoming as $rdv): ?>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <div>
                                        <strong><?= date('d/m', strtotime($rdv['dateR'])) ?></strong>
                                        <span class="text-muted">à <?= htmlspecialchars($rdv['heureR']) ?></span><br>
                                        <small>Dr. <?= htmlspecialchars($rdv['nomMedecin']) ?></small>
                                    </div>
                                    <span class="badge bg-primary rounded-pill"><?= date('D', strtotime($rdv['dateR'])) ?></span>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                    <?php foreach ($rendezVousList as $rdv): ?>
        <div class="rdv" data-idmedecin="<?= $rdv['idMedecin'] ?>"
                      data-dater="<?= $rdv['dateR'] ?>"
                      data-heurerdv="<?= $rdv['heureR'] ?>">
            <p><strong>Médecin :</strong> <?= $rdv['nom'] ?> <?= $rdv['prenom'] ?></p>
            <p><strong>Date :</strong> <?= $rdv['dateR'] ?> à <?= $rdv['heureR'] ?></p>
            <button class="btn-modifier">Modifier</button>

            <div class="form-modifier" style="display: none;">
                <label>Nouvelle date :</label>
                <input type="date" class="new-date" required>
                <label>Nouvelle heure :</label>
                <input type="time" class="new-heure" required>
                <button class="btn-valider-modif">Valider</button>
            </div>
        </div>
        <hr>
    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('dateR').min = new Date().toISOString().split('T')[0];

// Suppression de rendez-vous
document.querySelectorAll('.btn-outline-danger').forEach(btn => {
    btn.addEventListener('click', async function () {
        if (!confirm("Confirmez l'annulation du rendez-vous ?")) return;

        const idMedecin = this.dataset.idmedecin;
        const dateR = this.dataset.date;
        const heureR = this.dataset.heure;

        try {
            const response = await fetch('supprimer_rendezvous.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: `idMedecin=${idMedecin}&dateR=${dateR}&heureR=${heureR}`
            });

            const data = await response.json();
            if (!data.success) throw new Error(data.message || "Échec");

            const card = this.closest('.appointment-card');
            card.style.transition = 'all 0.3s';
            card.style.opacity = '0';
            setTimeout(() => card.remove(), 300);
        } catch (error) {
            alert("Erreur : " + error.message);
        }
    });
});

document.addEventListener("DOMContentLoaded", function () {
    // Quand on clique sur "Modifier"
    document.querySelectorAll(".btn-modifier").forEach(function (btn) {
        btn.addEventListener("click", function () {
            const parent = btn.closest(".rdv");
            const form = parent.querySelector(".form-modifier");
            form.style.display = (form.style.display === "none") ? "block" : "none";
        });
    });

    // Quand on clique sur "Valider"
    document.querySelectorAll(".btn-valider-modif").forEach(function (btn) {
        btn.addEventListener("click", function () {
            const parent = btn.closest(".rdv");
            const idMedecin = parent.dataset.idmedecin;
            const oldDate = parent.dataset.dater;
            const oldHeure = parent.dataset.heurerdv;
            const newDate = parent.querySelector(".new-date").value;
            const newHeure = parent.querySelector(".new-heure").value;

            if (!newDate || !newHeure) {
                alert("Veuillez remplir la date et l'heure.");
                return;
            }

            fetch("modifierRendezVous.php", {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                body: new URLSearchParams({
                    idMedecin: idMedecin,
                    oldDate: oldDate,
                    oldHeure: oldHeure,
                    newDate: newDate,
                    newHeure: newHeure
                })
            })
            .then(response => response.json())
            .then(data => {
                alert(data.message);
                if (data.success) {
                    location.reload(); // Pour mettre à jour les rendez-vous
                }
            })
            .catch(error => {
                console.error("Erreur :", error);
                alert("Une erreur s'est produite.");
            });
        });
    });
});


</script>
</body>
</html>
