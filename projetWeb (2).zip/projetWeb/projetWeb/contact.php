<?php
session_start();
require_once 'connexion.php';

if (!isset($_SESSION['cin'])) {
    header("Location: login.php");
    exit();
}

$idUser = $_SESSION['cin'];
$uploadDir = 'uploads/emergency/';

// Gestion de l'ajout de contact
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = $_POST['nomContact'];
    $numero = $_POST['numeroContact'];
    $photoPath = '';

    if (isset($_FILES['photo']) && $_FILES['photo']['error'] == 0) {
        $filename = time() . '_' . basename($_FILES['photo']['name']);
        $photoPath = $uploadDir . $filename;

        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        move_uploaded_file($_FILES['photo']['tmp_name'], $photoPath);
    }

    $stmt = $conn->prepare("INSERT INTO urgence (idUser, nom, telephone, photo) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $idUser, $nom, $numero, $photoPath);
    $stmt->execute();
    $success = "Contact ajouté avec succès.";
}

// Récupération des contacts d'urgence
$stmt = $conn->prepare("SELECT * FROM urgence 
WHERE idUser = ? ");
$stmt->bind_param("i", $idUser);
$stmt->execute();
$result = $stmt->get_result();
$contacts = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Contacts d'Urgence - MedSpeak</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .contact-card {
            border-radius: 10px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.1);
            overflow: hidden;
            transition: transform 0.2s ease;
        }
        .contact-card:hover {
            transform: scale(1.02);
        }
        .contact-photo {
            width: 100%;
            height: 200px;
            object-fit: cover;
            background-color: #e9ecef;
        }
    </style>
</head>
<body class="bg-light">

<div class="container py-5">
    <h2 class="mb-4 text-primary">📞 Contacts d'Urgence</h2>

    <?php if (isset($success)): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <!-- Formulaire d'ajout -->
    <div class="card mb-5">
        <div class="card-header bg-danger text-white">
            Ajouter un contact d'urgence
        </div>
        <div class="card-body">
            <form method="POST" enctype="multipart/form-data">
                <div class="mb-3">
                    <label for="nomContact" class="form-label">Nom du contact</label>
                    <input type="text" class="form-control" name="nomContact" id="nomContact" required>
                </div>
                <div class="mb-3">
                    <label for="numeroContact" class="form-label">Numéro de téléphone</label>
                    <input type="tel" class="form-control" name="numeroContact" id="numeroContact" required>
                </div>
                <div class="mb-3">
                    <label for="photo" class="form-label">Photo du contact (facultatif)</label>
                    <input type="file" class="form-control" name="photo" id="photo" accept="image/*">
                </div>
                <button type="submit" class="btn btn-danger w-100">Ajouter le contact</button>
            </form>
        </div>
    </div>

    <!-- Affichage des contacts -->
    <div class="row">
        <?php if (empty($contacts)): ?>
            <div class="alert alert-info">Aucun contact d'urgence enregistré.</div>
        <?php else: ?>
            <?php foreach ($contacts as $contact): ?>
                <div class="col-md-4 mb-4">
                    <div class="contact-card bg-white">
                        <?php if ($contact['photo']): ?>
                            <img src="<?= htmlspecialchars($contact['photo']) ?>" class="contact-photo" alt="Photo">
                        <?php else: ?>
                            <div class="contact-photo d-flex align-items-center justify-content-center text-muted">
                                Pas de photo
                            </div>
                        <?php endif; ?>
                        <div class="p-3">
                            <h5 class="card-title"><?= htmlspecialchars($contact['nom']) ?></h5>
                            <p class="mb-1"><strong>Téléphone :</strong> <?= htmlspecialchars($contact['telephone']) ?></p>
                           
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
