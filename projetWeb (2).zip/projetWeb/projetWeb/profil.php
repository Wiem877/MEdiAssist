<?php
session_start();
require_once 'connexion.php';

// Vérifier si la session contient un CIN
if (!isset($_SESSION['cin'])) {
    header("Location: accueil.php");
    exit();
}

$cin = $_SESSION['cin']; // Assurez-vous que $_SESSION['cin'] contient bien le CIN de l'utilisateur connecté.

// Récupérer les données de l'utilisateur à partir de la base de données
$stmt = $conn->prepare("SELECT * FROM utilisateur WHERE idUser = ?");
$stmt->bind_param("s", $cin);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Vérification si l'utilisateur existe bien dans la base de données
if (!$user) {
    echo "Aucun utilisateur trouvé avec ce CIN.";
    exit(); // Quitte le script si aucun utilisateur n'est trouvé
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Mon profile</title>
    <link href="profil.css" rel="stylesheet">
</head>
<body>
    <div class="content">
    <div class="profile-header">
        <img src="<?php echo $user['photo']; ?>" alt="Photo du patient" class="profile-image">
        <h2>Mon Profil</h2>
    </div>

    <!-- Champs du profil sous l'en-tête -->
    <div class="profile-details">
        <div class="form-group">
            <label>CIN:</label>
            <p><?= htmlspecialchars($user['idUser']) ?></p>
        </div>
        <div class="form-group">
            <label>Nom:</label>
            <p><?= htmlspecialchars($user['nom']) ?></p>
        </div>
        <div class="form-group">
            <label>Prénom:</label>
            <p><?= htmlspecialchars($user['prenom']) ?></p>
        </div>
        <div class="form-group">
            <label>Email:</label>
            <p><?= htmlspecialchars($user['email']) ?></p>
        </div>
    </div>
</div>

</body>
</html>
