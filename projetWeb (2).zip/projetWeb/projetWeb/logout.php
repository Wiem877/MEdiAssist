<?php
session_start();
session_destroy();
header("Location: bienvenue1.html");
exit();
?>