<?php
session_start();
require_once 'connexion.php';

// Vérification de session
if (!isset($_SESSION['cin'])) {
    header("Location: login.php");
    exit();
}

$idUser = $_SESSION['cin'];
$uploadDir = 'uploads/ordonnances/'; // Chemin relatif depuis htdocs/projetWeb

// Gestion de l'upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['ordonnanceFile'])) {
    $file = $_FILES['ordonnanceFile'];

    if ($file['error'] === 0 && $file['size'] < 5 * 1024 * 1024) {
        $filename = basename($file['name']);
        $targetPath = $uploadDir . time() . '_' . $filename;

        // Création du dossier si besoin
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        // Déplacement du fichier uploadé
        if (move_uploaded_file($file['tmp_name'], $targetPath)) {
            // 1. Ajouter dans ordonnance
            $stmt = $conn->prepare("INSERT INTO ordonnance (idUser, fichier, dateAjout) VALUES (?, ?, NOW())");
            $stmt->bind_param("is", $idUser, $targetPath);
            $stmt->execute();

            // 2. Récupérer le dernier idOrd inséré
            $idOrdonnance = $conn->insert_id;

            // 3. Ajouter dans ordMed
            $stmt2 = $conn->prepare("INSERT INTO ordMed (idUser, idOrd, dateOrd) VALUES (?, ?, NOW())");
            $stmt2->bind_param("ii", $idUser, $idOrdonnance);
            $stmt2->execute();

            $success = "Ordonnance importée avec succès.";
        } else {
            $error = "Erreur lors de l'import du fichier.";
        }
    } else {
        $error = "Fichier invalide (taille max: 5 Mo).";
    }
}

// Récupération des ordonnances
$stmt = $conn->prepare("
    SELECT o.* 
    FROM ordonnance o 
    JOIN ordMed om ON o.idOrd = om.idOrd
    WHERE o.idUser = ?
    ORDER BY om.dateOrd DESC
");
$stmt->bind_param("i", $idUser);
$stmt->execute();
$result = $stmt->get_result();
$ordonnances = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Mes Ordonnances - MedSpeak</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .upload-card {
            border: 2px dashed #0d6efd;
            padding: 30px;
            text-align: center;
            cursor: pointer;
            background-color: #f8f9fa;
        }
        .ordonnance-preview {
            border: 1px solid #dee2e6;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 15px;
        }
        h2
        {
            text-align:center;
            color: red;
            font-style: italic;
        }
        .ordonnance-preview {
    opacity: 0;
    transform: translateY(20px);
    animation: fadeInCard 0.6s ease forwards;
}

.ordonnance-preview:nth-child(1) { animation-delay: 0.1s; }
.ordonnance-preview:nth-child(2) { animation-delay: 0.2s; }
.ordonnance-preview:nth-child(3) { animation-delay: 0.3s; }
/* Tu peux continuer autant que nécessaire */


    </style>
</head>
<body class="bg-light">

<div class="container py-5">
    <h2 class="mb-4"><i class="bi bi-file-earmark-medical"></i> Historique des Ordonnances</h2>

    <?php if (isset($success)): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php elseif (isset($error)): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <!-- Formulaire d'import -->
    <div class="card mb-4">
        <div class="card-header bg-primary text-white">
            <strong>Importer une ordonnance</strong>
        </div>
        <div class="card-body">
            <form method="POST" enctype="multipart/form-data">
                <input type="file" name="ordonnanceFile" class="form-control mb-3" required>
                <button type="submit" class="btn btn-primary w-100">Télécharger</button>
            </form>
        </div>
    </div>

    <!-- Affichage des ordonnances -->
    <?php if (empty($ordonnances)): ?>
        <div class="alert alert-info">Aucune ordonnance enregistrée.</div>
    <?php else: ?>
        <div class="row">
            <?php foreach ($ordonnances as $ord): ?>
                <div class="col-md-6">
                    <div class="ordonnance-preview bg-white shadow-sm">
                        <p><strong>Date :</strong> <?= date('d/m/Y H:i', strtotime($ord['dateAjout'])) ?></p>
                        <a href="<?= 'http://' . $_SERVER['HTTP_HOST'] . '/projetWeb/' . htmlspecialchars($ord['fichier']) ?>" target="_blank" class="btn btn-outline-primary w-100">
                            Voir le document
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
