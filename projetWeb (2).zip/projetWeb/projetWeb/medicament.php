<?php
session_start();
require_once 'connexion.php';

if (!isset($_SESSION['cin'])) {
    header("Location: accueil.php");
    exit();
}

$cin = $_SESSION['cin'];
$stmt = $conn->prepare("SELECT * FROM medicament m ,utilisateur u, manger mg WHERE u.idUser = ? and u.idUser=mg.idUser and mg.idMedicament=m.idMedicament");
$stmt->bind_param("s", $cin);
$stmt->execute();
$medicaments = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Mes Médicaments</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }
        .container { background: #fff; padding: 20px; border-radius: 10px; box-shadow: 0 2px 6px rgba(0,0,0,0.2); }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ccc; padding: 12px; text-align: left; }
        th { background-color: #f0f0f0; }
        .btn { padding: 8px 14px; border: none; border-radius: 4px; cursor: pointer; margin-right: 10px; }
        .btn-success { background-color: #4CAF50; color: white; }
        .btn-danger { background-color: #e74c3c; color: white; }
        .btn-warning { background-color: #f39c12; color: white; }
        .form-section { display: none; margin-top: 20px; background: #f9f9f9; padding: 15px; border-radius: 8px; }
        label { display: block; margin-top: 10px; }
        input[type="text"] { width: 100%; padding: 8px; margin-top: 5px; border: 1px solid #ccc; border-radius: 4px; }
    </style>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
<div class="container">
    <h2>Mes Médicaments</h2>

    <!-- Boutons -->
    <button class="btn btn-success" id="btnAdd">Ajouter</button>
   

    <!-- Formulaire Ajout -->
    <form id="formAdd" class="form-section" action="medicament_action.php" method="post">
        <h4>Ajouter un médicament</h4>
        <label>Nom:</label>
        <input type="text" name="nom" required>
        <label>Dosage:</label>
        <input type="text" name="dosage" required>
        <label>Fréquence:</label>
        <input type="text" name="frequence" required>
        <label>Heure de prise:</label>
        <input type="text" name="heure" required>
        <button class="btn btn-success" type="submit">Ajouter</button>
    </form>

    <!-- Formulaire Modification -->
    <form id="formEdit" class="form-section">
        <h4>Modifier un médicament</h4>
        <input type="hidden" name="id">
        <label>Nom:</label>
        <input type="text" name="nom">
        <label>Dosage:</label>
        <input type="text" name="dosage">
        <label>Fréquence:</label>
        <input type="text" name="frequence">
        <label>Heure de prise:</label>
        <input type="text" name="heure">
        <button class="btn btn-warning" type="submit">Modifier</button>
    </form>

    <!-- Formulaire Suppression (simple confirmation) -->
    <form id="formDelete" class="form-section">
        <h4>Supprimer un médicament</h4>
        <input type="hidden" name="id">
        <p>Confirmer la suppression de <strong id="deleteNom"></strong> ?</p>
        <button class="btn btn-danger" type="submit">Supprimer</button>
    </form>

    <!-- Tableau -->
    <table id="medicamentTable">
        <thead>
            <tr>
                <th>Nom</th>
                <th>Dosage</th>
                <th>Fréquence</th>
                <th>Heure de prise</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($medicaments as $med): ?>
                <tr data-id="<?= $med['idMedicament'] ?>">
                    <td><?= htmlspecialchars($med['nomMedicament']) ?></td>
                    <td><?= htmlspecialchars($med['posMedicament']) ?></td>
                    <td><?= htmlspecialchars($med['freqMedicament']) ?></td>
                    <td><?= htmlspecialchars($med['heurePrise']) ?></td>

                    <td>
                        <button class="btn btn-warning editBtn">Modifier</button>
                        <button class="btn btn-danger deleteBtn">Supprimer</button>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<script>
$(document).ready(function() {
    // Toggle formulaires selon le bouton cliqué
    $('#btnAdd').click(() => {
        $('.form-section').hide();
        $('#formAdd').slideToggle();
    });
    $('#btnEdit').click(() => {
        $('.form-section').hide();
        alert("Cliquez sur le bouton Modifier d'une ligne pour modifier.");
    });
    $('#btnDelete').click(() => {
        $('.form-section').hide();
        alert("Cliquez sur le bouton Supprimer d'une ligne pour supprimer.");
    });

    // Ajouter médicament
    $('#formAdd').submit(function(e) {
        e.preventDefault();
        $.post('medicament_action.php', $(this).serialize() + '&action=add', function(data) {
            location.reload();
        });
    });

    // Pré-remplir et afficher le formulaire de modification
    $('.editBtn').click(function() {
        $('.form-section').hide();
        const row = $(this).closest('tr');
        const id = row.data('id');
        const nom = row.find('td:eq(0)').text();
        const dosage = row.find('td:eq(1)').text();
        const frequence = row.find('td:eq(2)').text();

        $('#formEdit input[name="id"]').val(id);
        $('#formEdit input[name="nom"]').val(nom);
        $('#formEdit input[name="dosage"]').val(dosage);
        $('#formEdit input[name="frequence"]').val(frequence);
        $('#formEdit').slideDown();
    });

    // Modifier médicament
    $('#formEdit').submit(function(e) {
        e.preventDefault();
        $.post('medicament_action.php', $(this).serialize() + '&action=edit', function(data) {
            location.reload();
        });
    });

    // Pré-remplir et afficher le formulaire de suppression
    $('.deleteBtn').click(function() {
        $('.form-section').hide();
        const row = $(this).closest('tr');
        const id = row.data('id');
        const nom = row.find('td:eq(0)').text();

        $('#formDelete input[name="id"]').val(id);
        $('#deleteNom').text(nom);
        $('#formDelete').slideDown();
    });

    // Supprimer médicament
    $('#formDelete').submit(function(e) {
        e.preventDefault();
        $.post('medicament_action.php', $(this).serialize() + '&action=delete', function(data) {
            location.reload();
        });
    });
});
</script>
</body>
</html>

