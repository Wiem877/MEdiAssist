<?php
require_once 'connexion.php';
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $cin = $_POST["cin"];
    $password = $_POST["psw"];

    // Vérification d'existence de user
    $stmt = $conn->prepare("SELECT * FROM utilisateur WHERE idUser = ?");
    $stmt->bind_param("s", $cin);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && password_verify($password, $user['mdp'])) {
        $_SESSION['cin'] = $user['idUser'];  // Sauvegarde dans la session
        header("Location: accueil.php");  // Redirection vers l'accueil
        exit();
    } else {
        echo "<script>alert('CIN ou mot de passe incorrect'); window.history.back();</script>";
    }

    $stmt->close();
}
?>



