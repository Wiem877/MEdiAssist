<?php
require_once 'connexion.php';
session_start();
$cin = $_POST['cin'];
$nom = $_POST['nom'];
$prenom = $_POST['prenom'];
$pwd = $_POST['mdp'];
$mail = $_POST['mail'];

$photo_nom = $_FILES['photo']['name'];// récupère le nom original d'image
$photo_tmp = $_FILES['photo']['tmp_name']; //récupère le chemin temporaire d'image
$photo_path = "uploads/" . uniqid() . "_" . basename($photo_nom);

// Vérifie que le dossier 'uploads/' existe
if (!file_exists("uploads")) {
    mkdir("uploads", 0777, true);
}

// Déplace l’image vers le dossier
move_uploaded_file($photo_tmp, $photo_path);
// Vérification si l'utilisateur existe déjà
$sql_check = "SELECT COUNT(*) FROM utilisateur WHERE idUser = ?";
$stmt_check = $conn->prepare($sql_check);
$stmt_check->bind_param("s", $cin);
$stmt_check->execute();
$stmt_check->bind_result($count);
$stmt_check->fetch();
$stmt_check->close();

if ($count > 0) {
    echo "<script>alert('Cet utilisateur existe déjà !'); window.location.href = 'signup.html';</script>";
    exit();
}

// Hashage du mot de passe
$pwd_hash = password_hash($pwd, PASSWORD_BCRYPT);

// Insertion de l'utilisateur dans la base de données
$sql = "INSERT INTO utilisateur (idUser, nom, prenom, mdp, email,photo) VALUES (?,?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);

if ($stmt) {
    $stmt->bind_param("ssssss", $cin, $nom, $prenom, $pwd_hash, $mail,$photo_path);
    if ($stmt->execute()) {
        $_SESSION['cin'] = $cin;  // Sauvegarde de l'ID de l'utilisateur dans la session
        header("Location: accueil.php");  // Redirection vers la page d'accueil
        exit();
    } else {
        echo "Erreur lors de l'exécution : " . $stmt->error;
    }
    $stmt->close();
} else {
    echo "Erreur de préparation : " . $conn->error;
}

$conn->close();
?>




