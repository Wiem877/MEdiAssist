<?php
session_start();
require_once 'connexion.php';

if (!isset($_SESSION['cin'])) {
    echo json_encode(['success' => false, 'message' => 'Non autorisé']);
    exit;
}

$idUser = $_SESSION['cin'];
$idMedecin = $_POST['idMedecin'] ?? null;
$dateR = $_POST['dateR'] ?? null;
$heureR = $_POST['heureR'] ?? null;

if (!$idMedecin || !$dateR || !$heureR) {
    echo json_encode(['success' => false, 'message' => 'Données manquantes']);
    exit;
}

$stmt = $conn->prepare("DELETE FROM RendezVous WHERE idUser = ? AND idMedecin = ? AND dateR = ? AND heureR = ?");
$stmt->bind_param("iiss", $idUser, $idMedecin, $dateR, $heureR);
$success = $stmt->execute();

if ($success) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'Échec de la suppression']);
}
