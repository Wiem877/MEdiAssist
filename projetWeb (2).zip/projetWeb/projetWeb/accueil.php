<?php
session_start();
$current_section = basename($_SERVER['PHP_SELF'], ".php"); // définit automatiquement la section
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MediAssist</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        @keyframes animatedBackground {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
}

body {
    background: linear-gradient(-45deg, #cbb2f0, #a88ede, #f8f9fa, #ffffff); /*degradation*/
    background-size: 400% 400%;
    animation: animatedBackground 20s ease infinite;
}
        /* menu */
        .sidebar {
            width: 220px;
            height: 100vh;
            background: linear-gradient(180deg, #cbb2f0, #a88ede);
            padding-top: 20px;
            position: fixed;
            left: 0;
            top: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            box-shadow: 2px 0 8px rgba(0,0,0,0.1);
        }

        .sidebar h2 {
            color: white;
            margin-bottom: 40px;
            font-size: 24px;
        }

        .sidebar a {
            color: white;
            text-decoration: none;
            margin: 10px 0;
            font-size: 16px;
            width: 100%;
            text-align: center;
            padding: 10px;
            transition: 0.3s;
        }

        .sidebar a:hover {
            background-color: rgba(255, 255, 255, 0.2);
            border-radius: 8px;
        }

        /* Main content */
        .main-content {
            margin-left: 240px;
            padding: 30px;
            flex: 1;
        }

        .header {
            text-align: center;
            margin-bottom: 40px;
        }

        h1 {
            color: #343a40;
            font-size: 32px;
        }

        .menu {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 20px;
}

.card {
    background-color: white;
    width: 180px;
    height: 180px;
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.05);
    text-align: center;
    transition: transform 0.3s, background-color 0.3s;
    cursor: pointer;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    color: violet;
}


        .card:hover {
            transform: translateY(-5px);
            background-color: #f0f0f0;
        }

        .card i {
            font-size: 28px;
            margin-bottom: 10px;
            color: #6c63ff;
        }

        .card p {
            margin: 0;
            font-weight: bold;
            color: #333;
        }
        .title-with-logo {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
}

.logo {
    width: 100px;
    height: 120px;
    object-fit: contain;
}
    </style>
</head>
<body>

    <!-- Sidebar -->
    <div class="sidebar">
        <h2>MediSpeak</h2>
        <a href="#"><i class="fas fa-cog"></i> Paramètres</a>
        <a href="#"><i class="fas fa-share-alt"></i> Partager</a>
        <a href="#"><i class="fas fa-info-circle"></i> À propos</a>
        <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Déconnexion</a>
    </div>

    <!-- Main content -->
    <div class="main-content">
    <div class="header">
    <div class="title-with-logo">
        <img src="uploads\logo.png" alt="Logo" class="logo">
        <h1>MediAssist</h1>
    </div>
</div>
        <div class="menu">
            <div class="card" onclick="window.location='profil.php'">
                <i class="fas fa-user"></i>
                <p>Profil</p>
            </div>
            <div class="card" onclick="window.location='medicament.php'">
                <i class="fas fa-pills"></i>
                <p>Mes Médicaments</p>
            </div>
            <div class="card" onclick="window.location='contact.php'">
                <i class="fas fa-phone"></i>
                <p>Contact d'urgence</p>
            </div>
            <div class="card" onclick="window.location='appointment.php'">
                <i class="fas fa-calendar-check"></i>
                <p>Appointment</p>
            </div>
            <div class="card" onclick="window.location='ordonnance.php'">
                <i class="fas fa-file-medical"></i>
                <p>Mes Ordonnances</p>
            </div>
            <div class="card" onclick="window.location='emploi.php'">
                <i class="fas fa-clock"></i>
                <p>Emploi des rendez-vous</p>
            </div>
        </div>
    </div>

</body>
</html>
