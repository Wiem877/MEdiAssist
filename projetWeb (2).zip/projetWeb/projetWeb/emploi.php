<?php
session_start();
require_once 'connexion.php';

if (!isset($_SESSION['cin'])) {
    exit("Non autorisé");
}

$idUser = $_SESSION['cin'];

// Récupérer les rendez-vous
$stmt = $conn->prepare("
    SELECT dateR, heureR, typeCons, M.nomMedecin
    FROM RendezVous R
    JOIN Medecin M ON R.idMedecin = M.idMedecin
    WHERE R.idUser = ?
");
$stmt->bind_param("i", $idUser);
$stmt->execute();
$result = $stmt->get_result();

$events = [];
while ($row = $result->fetch_assoc()) {
    $events[] = [
        'title' => "Rdv: " . $row['typeCons'] . " - Dr. " . $row['nomMedecin'],
        'start' => $row['dateR'] . 'T' . $row['heureR'],
        'color' => '#0d6efd',
    ];
}
// Récupérer les médicaments
$stmt = $conn->prepare("
    SELECT nomMedicament, heurePrise
    FROM medicament m 
    join manger mg on m.idMedicament=mg.idMedicament 
    join utilisateur u on u.idUser=mg.idUser WHERE u.idUser = ?
");
$stmt->bind_param("i", $idUser);
$stmt->execute();
$result = $stmt->get_result();

$today = new DateTime();
$limit = new DateTime('+7 days');

while ($row = $result->fetch_assoc()) {
    // Ajouter un événement médicament pour chaque jour à venir (sur 7 jours par exemple)
    $tempDate = clone $today;
    while ($tempDate <= $limit) {
        $events[] = [
            'title' => "Médicament: " . $row['nomMedicament'],
            'start' => $tempDate->format('Y-m-d') . 'T' . $row['heurePrise'],
            'color' => '#20c997',
        ];
        $tempDate->modify('+1 day');
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Schedule - MedSpeak</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.css" rel="stylesheet">
    <style>
        body {
            background: #f8f9fa;
        }
        #calendar {
            max-width: 900px;
            margin: 50px auto;
            background: white;
            padding: 20px;
            border-radius: 16px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>

<div id="calendar"></div>

<script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const calendarEl = document.getElementById('calendar');

        const calendar = new FullCalendar.Calendar(calendarEl, {
            initialView: 'dayGridMonth',
            locale: 'fr',
            headerToolbar: {
                left: 'prev,next today',
                center: 'title',
                right: 'dayGridMonth,timeGridWeek,listWeek'
            },
            events: <?= json_encode($events) ?>
        });

        calendar.render();
    });
</script>

</body>
</html>
