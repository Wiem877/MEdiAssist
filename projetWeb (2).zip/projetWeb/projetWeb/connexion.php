<?php


    $conn = new mysqli("localhost","root","root","gestionPatient");
    if ($conn->connect_error) {
        die("Connexion échouée : " . $conn->connect_error);
        }
        
    
?>
