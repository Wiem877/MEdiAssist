<?php
session_start();
require_once 'connexion.php';

$idUser = $_POST['idUser'];
$idMedecin = $_POST['idMedecin'];
$oldDate = $_POST['oldDate'];
$oldHeure = $_POST['oldHeure'];
$newDate = $_POST['newDate'];
$newHeure = $_POST['newHeure'];

try {
    $stmt = $conn->prepare("UPDATE RendezVous SET dateR = ?, heureR = ? WHERE idUser = ? AND idMedecin = ? AND dateR = ? AND heureR = ?");
    $stmt->execute([$newDate, $newHeure, $idUser, $idMedecin, $oldDate, $oldHeure]);

    echo "Rendez-vous modifié avec succès. <a href='appointment.php'>Retour</a>";
} catch (PDOException $e) {
    echo "Erreur : " . $e->getMessage();
}
