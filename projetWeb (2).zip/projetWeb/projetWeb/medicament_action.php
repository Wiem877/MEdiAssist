<?php
session_start();
require_once 'connexion.php';

if (!isset($_SESSION['cin'])) {
    exit("Non autorisé");
}

$cin = $_SESSION['cin'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];

    if ($action === 'add') {
        $nom = $_POST['nom'];
        $dosage = $_POST['dosage'];
        $frequence = $_POST['frequence'];
        $heure = $_POST['heure'];

        // 1. Insérer dans medicament
        $stmt = $conn->prepare("INSERT INTO medicament (nomMedicament, posMedicament, freqMedicament, heurePrise) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("sdis", $nom, $dosage, $frequence, $heure);

        if ($stmt->execute()) {
            $idMedicament = $conn->insert_id;

            // 2. Associer avec utilisateur via manger
            $stmt2 = $conn->prepare("INSERT INTO manger (idUser, idMedicament) VALUES (?, ?)");
            $stmt2->bind_param("si", $cin, $idMedicament);

            if ($stmt2->execute()) {
                echo "success";
            } else {
                echo "Erreur lors de l'association du médicament.";
            }
        } else {
            echo "Erreur lors de l'ajout.";
        }

    } elseif ($action === 'edit') {
        $id = $_POST['id'];
        $nom = $_POST['nom'];
        $dosage = $_POST['dosage'];
        $frequence = $_POST['frequence'];
        $heure = $_POST['heure'];

        $stmt = $conn->prepare("UPDATE medicament SET nomMedicament = ?, posMedicament = ?, freqMedicament = ?, heurePrise = ? WHERE idMedicament = ?");
        $stmt->bind_param("sdisi", $nom, $dosage, $frequence, $heure, $id);

        if ($stmt->execute()) {
            echo "success";
        } else {
            echo "Erreur lors de la modification.";
        }

    } elseif ($action === 'delete') {
        $id = $_POST['id'];

        // Supprimer d'abord dans `manger` à cause de la contrainte
        $stmt1 = $conn->prepare("DELETE FROM manger WHERE idUser = ? AND idMedicament = ?");
        $stmt1->bind_param("si", $cin, $id);
        $stmt1->execute();

        // Ensuite supprimer dans `medicament`
        $stmt = $conn->prepare("DELETE FROM medicament WHERE idMedicament = ?");
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            echo "success";
        } else {
            echo "Erreur lors de la suppression.";
        }

    } else {
        echo "Action inconnue.";
    }
} else {
    echo "Requête invalide.";
}
?>



